﻿using HealthMetrics.Models;
using HealthMetrics.Data;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net.Http;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HealthMetrics.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly static string Api = "https://data.cdc.gov/resource/i2ek-k3pa.json";

        private ApplicationDbContext context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            this.context = context;
        }

        public async Task<IActionResult> LoadDataFromApi()
        {
            using var transaction = context.Database.BeginTransaction();
            try
            {
                context.StateData.RemoveRange(context.StateData);
                context.CityData.RemoveRange(context.CityData);
                context.GeographicMeasureData.RemoveRange(context.GeographicMeasureData);
                context.HealthData.RemoveRange(context.HealthData);
                await context.SaveChangesAsync();

                var client = new HttpClient();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await client.GetAsync(Api);
                if (!response.IsSuccessStatusCode)
                {
                    return StatusCode((int)response.StatusCode, "API request error");
                }

                var jsonString = await response.Content.ReadAsStringAsync();
                var healthDataDtos = JsonSerializer.Deserialize<List<HealthDataApiDto>>(jsonString)?.ToList();
                System.Diagnostics.Debug.WriteLine("FInal Health Data");
                System.Diagnostics.Debug.WriteLine(healthDataDtos);

                if (healthDataDtos == null || !healthDataDtos.Any())
                {
                    TempData["ErrorMessage"] = "No health data found in the API response.";
                    return RedirectToAction("Index");
                }

                foreach (var dto in healthDataDtos)
                {
                    if (string.IsNullOrWhiteSpace(dto.StateDesc))
                    {
                        dto.StateDesc = "Unknown";
                    }
                    var state = context.StateData.FirstOrDefault(s => s.StateName == dto.StateDesc);
                    if (state == null)
                    {
                        state = new State { StateName = dto.StateDesc };
                        context.StateData.Add(state);
                        context.SaveChanges();
                    }

                    if (string.IsNullOrWhiteSpace(dto.CityName))
                    {
                        dto.CityName = "Unknown"; // Default value for CityName if it's null or empty
                    }
                    var city = context.CityData.FirstOrDefault(c => c.CityName == dto.CityName && c.StateID == state.StateID)
                               ?? context.CityData.Add(new City { CityName = dto.CityName, StateID = state.StateID }).Entity;
                    context.SaveChanges();
                    
                    if (string.IsNullOrWhiteSpace(dto.Measure))
                    {
                        dto.Measure = "Unknown";
                    }
                    var measure = context.GeographicMeasureData.FirstOrDefault(m => m.MeasureName == dto.Measure);
                    if (measure == null)
                    {
                        measure = new GeographicMeasure { MeasureName = dto.Measure };
                        context.GeographicMeasureData.Add(measure);
                        context.SaveChanges() ;
                    }
                     

                    var healthData = context.HealthData.FirstOrDefault(h => h.DataID == dto.UniqueId)
                                     ?? new HealthData { DataID = dto.UniqueId };

                    // Map the DTO to your model properties
                    healthData.CityID = city.CityID;
                    healthData.MeasureID = measure.MeasureID;
                    healthData.LowConfidencyLimit = dto.LowConfidenceLimit;
                    healthData.HighConfidenceLimit = dto.HighConfidenceLimit;
                    healthData.Year = dto.Year;
                    healthData.PopulationCount= dto.PopulationCount;

                    context.HealthData.Add(healthData);
                    context.SaveChanges();

                }

                await context.SaveChangesAsync();
                await transaction.CommitAsync();

                TempData["SuccessMessage"] = "Health data loaded successfully.";
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "An error occurred while loading data from the API.");
                TempData["ErrorMessage"] = "An error occurred while processing the data.";
                // You might want to redirect to an error page or handle the error accordingly.
            }

            return RedirectToAction("Index");
        }


        public IActionResult Index() { return View(); }

        public async Task<IActionResult> Search()
        {
            var results = await context.CityData
                                    .Include(c => c.HealthDataRecords)
                                    .ThenInclude(hd => hd.GeographicMeasure)
                                    .ToListAsync();

            // Pass the search results to the view
            return View(results);
        }

        public async Task<IActionResult> SearchCity(string cityInput)
        {
            System.Diagnostics.Debug.WriteLine(cityInput);
            var results =  await context.CityData
                                    .Where(c => c.CityName.Contains(cityInput))
                                    .Include(c => c.HealthDataRecords)
                                    .ThenInclude(hd => hd.GeographicMeasure)
                                    .ToListAsync();

            // Pass the search results to the view
            return View(results);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null || id == 0) return NotFound();
            HealthData p = context.HealthData.Find(id);
            return View("ViewSingle", p);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(HealthData p)
        {
            if (p == null || p.DataID == 0) return NotFound();
            context.HealthData.Update(p);
            context.SaveChanges();
            return RedirectToAction("Search"); ;
        }

        public ActionResult Delete(int? id)
        {
            System.Diagnostics.Debug.WriteLine("Health Data Delete");
            System.Diagnostics.Debug.WriteLine(id);
            HealthData data = context.HealthData.Find(id);
            context.HealthData.Remove(data);
            context.SaveChanges();
            return RedirectToAction("Search");
        }

        public IActionResult Create()
        {
            var cities = context.CityData.ToList();
            var measures = context.GeographicMeasureData.ToList();

            // Create SelectList for cities and measures
            ViewBag.CityID = new SelectList(cities, "CityID", "CityName");
            ViewBag.MeasureID = new SelectList(measures, "MeasureID", "MeasureName");

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(HealthData p)
        {
            if (p == null) return BadRequest();
            HealthData f = p;
            System.Diagnostics.Debug.WriteLine(f);
            context.HealthData.Add(f);
            context.SaveChanges();
            return RedirectToAction("Search");
        }

        public IActionResult Graph()
        {
            var topCitiesByPopulation = context.HealthData
            .GroupBy(hd => hd.CityID) // Group by CityID to aggregate
            .Select(g => new
            {
                CityName = g.First().City.CityName, // This assumes navigation property is correctly set up
                TotalPopulation = g.Sum(hd => hd.PopulationCount) // Assuming PopulationCount is a property in HealthData
            })
            .OrderByDescending(g => g.TotalPopulation)
            .Take(5)
            .ToList();
            
            ViewBag.HealthDataByJSON = JsonSerializer.Serialize(topCitiesByPopulation.Select(c => new { c.CityName, c.TotalPopulation}));
            return View();
        }

        public IActionResult AboutUs()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}