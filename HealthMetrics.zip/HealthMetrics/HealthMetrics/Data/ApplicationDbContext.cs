﻿using Microsoft.EntityFrameworkCore;
using HealthMetrics.Models;
using System.Collections.Generic;

namespace HealthMetrics.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<State> StateData{ get; set; }
        public DbSet<City> CityData{ get; set; }
        public DbSet<HealthData> HealthData{ get; set; }
        public DbSet<GeographicMeasure> GeographicMeasureData { get; set; }
    }
}
