﻿namespace HealthMetrics.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Globalization;
    using System.Text.Json;
    using System.Text.Json.Serialization;

    public class State
    {
        [Key]
        public int StateID { get; set; }

        [Required]
        [MaxLength(100)]
        public string StateName { get; set; } // Assuming 'State' is a reserved keyword, use StateName instead.

        public virtual ICollection<City> Cities { get; set; }

        public State()
        {
            Cities = new HashSet<City>();
        }
    }

    public class City
    {
        [Key]
        public int CityID { get; set; }

        [Required]
        [MaxLength(100)]
        public string CityName { get; set; } // Using CityName instead of 'City' to avoid conflicts with reserved keywords.

        [ForeignKey("State")]
        public int StateID { get; set; }

        public virtual State State { get; set; }
        public virtual ICollection<HealthData> HealthDataRecords { get; set; }

        public City()
        {
            HealthDataRecords = new HashSet<HealthData>();
        }
    }

    public class HealthData
    {
        [Key]
        public int DataID { get; set; }

        [ForeignKey("City")]
        public int CityID { get; set; }

        [ForeignKey("GeographicMeasure")]
        public int MeasureID { get; set; }

        public double LowConfidencyLimit { get; set; }
        public double HighConfidenceLimit { get; set; }

        public int Year { get; set; }

        public int PopulationCount { get; set; }

        public virtual City City { get; set; }
        public virtual GeographicMeasure GeographicMeasure { get; set; }
    }

    public class GeographicMeasure
    {
        [Key]
        public int MeasureID { get; set; }

        [Required]
        [MaxLength(100)]
        public string MeasureName { get; set; } // Using MeasureName instead of 'Measure' to avoid conflicts.

        public virtual ICollection<HealthData> HealthDataRecords { get; set; }

        public GeographicMeasure()
        {
            HealthDataRecords = new HashSet<HealthData>();
        }
    }

    public class HealthDataApiDto
    {
        public int UniqueId { get; set; }
        [JsonPropertyName("cityname")]
        public string CityName { get; set; }
        public GeolocationDto Geolocation { get; set; }
        public double DataValue { get; set; }
        [JsonPropertyName("populationcount")]
        [JsonConverter(typeof(StringToIntConverter))]
        public int PopulationCount { get; set; }
        [JsonPropertyName("measure")]
        public string Measure { get; set; }
        [JsonPropertyName("low_confidence_limit")]
        [JsonConverter(typeof(StringToDoubleConverter))]
        public double LowConfidenceLimit { get; set; }
        [JsonPropertyName("high_confidence_limit")]
        [JsonConverter(typeof(StringToDoubleConverter))]
        public double HighConfidenceLimit { get; set; }
        public string GeographicalLevel { get; set; }
        public string DataSource { get; set; }
        public string CategoryId { get; set; }
        public string DataValueUnit { get; set; }
        public string Category { get; set; }
        [JsonPropertyName("year")]
        [JsonConverter(typeof(StringToIntConverter))]
        public int Year { get; set; }
        [JsonPropertyName("cityfips")]
        public string CityFips { get; set; }
        public string DataValueType { get; set; }
        public string StateAbbr { get; set; }
        public string ShortQuestionText { get; set; }
        public string MeasureId { get; set; }
        [JsonPropertyName("statedesc")]
        public string StateDesc { get; set; }
        public string DataValueTypeId { get; set; }

        public class GeolocationDto
        {
            public double Latitude { get; set; }
            public string HumanAddress { get; set; }
            public bool NeedsRecoding { get; set; }
            public double Longitude { get; set; }
        }
    }
    public class StringToIntConverter : JsonConverter<int>
    {
        public override int Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.String)
            {
                string stringValue = reader.GetString();
                if (int.TryParse(stringValue, out int intValue))
                {
                    return intValue;
                }
                throw new JsonException("Cannot convert string to int.");
            }
            return reader.GetInt32();
        }

        public override void Write(Utf8JsonWriter writer, int value, JsonSerializerOptions options)
        {
            writer.WriteNumberValue(value);
        }
    }
    public class StringToFloatConverter : JsonConverter<float>
    {
        public override float Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.String)
            {
                string stringValue = reader.GetString();
                if (float.TryParse(stringValue, out float floatValue))
                {
                    return floatValue;
                }
                throw new JsonException("Cannot convert string to float.");
            }
            return reader.GetSingle();
        }

        public override void Write(Utf8JsonWriter writer, float value, JsonSerializerOptions options)
        {
            writer.WriteNumberValue(value);
        }
    }

    public class StringToDoubleConverter : JsonConverter<double>
    {
        public override double Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.String)
            {
                string stringValue = reader.GetString();
                if (double.TryParse(stringValue, NumberStyles.Any, CultureInfo.InvariantCulture, out double doubleValue))
                {
                    return doubleValue;
                }
                throw new JsonException("Cannot convert string to double.");
            }
            return reader.GetDouble();
        }

        public override void Write(Utf8JsonWriter writer, double value, JsonSerializerOptions options)
        {
            writer.WriteNumberValue(value);
        }
    }

}
